<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class WP_Imprint {

    public function init(): void {
        add_action( 'init', 'imprint_register_post_type' );
        add_action( 'init', 'imprint_register_post_meta' );
        add_action( 'init', 'imprint_register_block' );
        add_action( 'rest_api_init', 'imprint_register_rest_routes' );
        add_filter( 'post_row_actions', [ $this, 'add_canonical_row_action' ], 10, 2 );
        add_action( 'admin_action_imprint_set_canonical', [ $this, 'handle_set_canonical' ] );
        add_action( 'admin_menu', [ $this, 'add_settings_page' ] );
    }

    public function add_canonical_row_action( array $actions, WP_Post $post ): array {
        if ( 'imprint' !== $post->post_type ) {
            return $actions;
        }
        if ( (bool) get_post_meta( $post->ID, '_imprint_canonical', true ) ) {
            $actions['imprint_canonical'] = '<span style="color:#3fb950">&#9733; canonical</span>';
        } else {
            $url = wp_nonce_url(
                admin_url( 'admin.php?action=imprint_set_canonical&post_id=' . $post->ID ),
                'imprint_set_canonical_' . $post->ID
            );
            $actions['imprint_set_canonical'] = '<a href="' . esc_url( $url ) . '">Set as canonical</a>';
        }
        return $actions;
    }

    public function handle_set_canonical(): void {
        $post_id = isset( $_GET['post_id'] ) ? absint( $_GET['post_id'] ) : 0;
        check_admin_referer( 'imprint_set_canonical_' . $post_id );

        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            wp_die( esc_html__( 'You do not have permission to do this.', 'wp-imprint' ) );
        }

        // Remove canonical flag from all imprint posts, then set on chosen post.
        $all = get_posts( [ 'post_type' => 'imprint', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids' ] );
        foreach ( $all as $id ) {
            delete_post_meta( (int) $id, '_imprint_canonical' );
        }
        update_post_meta( $post_id, '_imprint_canonical', true );

        wp_safe_redirect( admin_url( 'edit.php?post_type=imprint&imprint_canonical_set=1' ) );
        exit;
    }

    public function add_settings_page(): void {
        add_options_page(
            __( 'Imprint Settings', 'wp-imprint' ),
            __( 'Imprint', 'wp-imprint' ),
            'manage_options',
            'wp-imprint',
            [ $this, 'render_settings_page' ]
        );
    }

    public function render_settings_page(): void {
        $canonical = imprint_get_canonical_post();
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Imprint Settings', 'wp-imprint' ); ?></h1>
            <?php if ( isset( $_GET['imprint_canonical_set'] ) ) : ?>
                <div class="notice notice-success is-dismissible">
                    <p><?php esc_html_e( 'Canonical imprint updated.', 'wp-imprint' ); ?></p>
                </div>
            <?php endif; ?>
            <?php if ( $canonical ) : ?>
                <p>
                    <?php esc_html_e( 'Current canonical imprint:', 'wp-imprint' ); ?>
                    <strong><?php echo esc_html( $canonical->post_title ); ?></strong>
                    (<?php echo esc_html( get_post_meta( $canonical->ID, '_imprint_platform', true ) ); ?>)
                    &mdash;
                    <a href="<?php echo esc_url( get_edit_post_link( $canonical->ID ) ); ?>">
                        <?php esc_html_e( 'Edit', 'wp-imprint' ); ?>
                    </a>
                </p>
            <?php else : ?>
                <p><?php esc_html_e( 'No Imprint found. Import one using the Imprint web tool.', 'wp-imprint' ); ?></p>
            <?php endif; ?>
            <p>
                <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=imprint' ) ); ?>" class="button">
                    <?php esc_html_e( 'Manage Imprints', 'wp-imprint' ); ?>
                </a>
            </p>
        </div>
        <?php
    }
}

<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function imprint_register_rest_routes(): void {
    register_rest_route( 'imprint/v1', '/me', [
        'methods'             => WP_REST_Server::READABLE,
        'callback'            => 'imprint_rest_me',
        'permission_callback' => '__return_true',
    ] );
    register_rest_route( 'imprint/v1', '/all', [
        'methods'             => WP_REST_Server::READABLE,
        'callback'            => 'imprint_rest_all',
        'permission_callback' => '__return_true',
    ] );
}

/**
 * Formats a single imprint post for REST response.
 *
 * @param WP_Post $post
 * @param bool    $include_content Whether to include the full markdown content field.
 * @return array<string, mixed>
 */
function imprint_format_post( WP_Post $post, bool $include_content ): array {
    $platform     = (string) get_post_meta( $post->ID, '_imprint_platform', true );
    $version      = (string) get_post_meta( $post->ID, '_imprint_version', true );
    $source_date  = (string) get_post_meta( $post->ID, '_imprint_source_date', true );
    $is_canonical = (bool) get_post_meta( $post->ID, '_imprint_canonical', true );

    $data = [
        'id'          => $post->ID,
        'url'         => get_permalink( $post->ID ),
        'title'       => $post->post_title,
        'platform'    => $platform,
        'source_date' => $source_date,
        'version'     => $version,
        'avatar'      => imprint_generate_avatar( $post ),
        'canonical'   => $is_canonical,
        'modified'    => mysql2date( 'c', $post->post_modified_gmt, false ),
    ];

    if ( $include_content ) {
        $data['content'] = $post->post_content;
    }

    return $data;
}

/**
 * @return WP_REST_Response|WP_Error
 */
function imprint_rest_me( WP_REST_Request $request ) {
    $post = imprint_get_canonical_post();

    if ( ! $post ) {
        return new WP_Error(
            'no_imprint',
            __( 'No Imprint found.', 'wp-imprint' ),
            [ 'status' => 404 ]
        );
    }

    return new WP_REST_Response( imprint_format_post( $post, is_user_logged_in() ), 200 );
}

function imprint_rest_all( WP_REST_Request $request ): WP_REST_Response {
    $posts = get_posts( [
        'post_type'   => 'imprint',
        'post_status' => 'publish',
        'numberposts' => -1,
        'orderby'     => 'date',
        'order'       => 'DESC',
    ] );

    $include_content = is_user_logged_in();
    $data = array_map(
        fn( WP_Post $p ) => imprint_format_post( $p, $include_content ),
        $posts
    );

    return new WP_REST_Response( $data, 200 );
}

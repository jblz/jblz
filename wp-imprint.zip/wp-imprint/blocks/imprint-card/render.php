<?php
/**
 * Block render template for wp-imprint/imprint-card.
 * Called automatically by WordPress via the `render` field in block.json.
 * Variables available: $attributes (array), $content (string), $block (WP_Block).
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$post = imprint_get_canonical_post();

if ( ! $post ) {
    printf(
        '<div %s><p>%s <a href="https://automattic.github.io/data-liberation-agent/">%s</a></p></div>',
        get_block_wrapper_attributes( [ 'class' => 'imprint-empty' ] ),
        esc_html__( 'No Imprint found.', 'wp-imprint' ),
        esc_html__( 'Create one with the Imprint web tool →', 'wp-imprint' )
    );
    return;
}

$sections = imprint_parse_sections( $post->post_content );
$platform = esc_html( (string) get_post_meta( $post->ID, '_imprint_platform', true ) );
$date     = esc_html( (string) get_post_meta( $post->ID, '_imprint_source_date', true ) );
?>
<div <?php echo get_block_wrapper_attributes(); ?>>
    <div class="imprint-meta">✦ imprint ready &middot; <?php echo $platform; ?> &middot; <?php echo $date; ?></div>
    <div class="imprint-sections">
        <?php foreach ( $sections as $section ) : ?>
            <div class="imprint-section">
                <h3 class="imprint-section-heading"><?php echo esc_html( $section['heading'] ); ?></h3>
                <p class="imprint-section-content"><?php echo nl2br( esc_html( $section['content'] ) ); ?></p>
            </div>
        <?php endforeach; ?>
    </div>
</div>

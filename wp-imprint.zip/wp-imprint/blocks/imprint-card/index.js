( function ( blocks, element ) {
    'use strict';
    blocks.registerBlockType( 'wp-imprint/imprint-card', {
        edit: function () {
            return element.createElement(
                'div',
                { className: 'wp-block-wp-imprint-imprint-card imprint-editor-placeholder' },
                'Your Imprint will appear here.'
            );
        },
        save: function () {
            return null; // server-rendered
        },
    } );
} )( window.wp.blocks, window.wp.element );

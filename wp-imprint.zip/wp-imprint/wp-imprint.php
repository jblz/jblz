<?php
/**
 * Plugin Name: WP Imprint
 * Description: Portable AI identity as a WordPress custom post type.
 * Version:     0.1.0
 * Requires at least: 6.3
 * Requires PHP: 7.4
 * Text Domain: wp-imprint
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'WP_IMPRINT_VERSION', '0.1.0' );
define( 'WP_IMPRINT_DIR', plugin_dir_path( __FILE__ ) );
define( 'WP_IMPRINT_URL', plugin_dir_url( __FILE__ ) );

require_once WP_IMPRINT_DIR . 'includes/cpt.php';
require_once WP_IMPRINT_DIR . 'includes/rest-api.php';
require_once WP_IMPRINT_DIR . 'includes/class-wp-imprint.php';

add_action( 'plugins_loaded', function() {
    ( new WP_Imprint() )->init();
} );

register_activation_hook( __FILE__, 'imprint_activate' );
register_deactivation_hook( __FILE__, 'imprint_deactivate' );
